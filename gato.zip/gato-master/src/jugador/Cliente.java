package jugador;

import java.awt.Image;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;


public class Cliente implements Runnable{
    //Declaramos las variables necesarias para la conexion y comunicacion
    private Socket cliente;
    private DataOutputStream out;
    private DataInputStream in;
    //El puerto debe ser el mismo en el que escucha el servidor
    private int puerto = 2027;
    //Si estamos en nuestra misma maquina usamos localhost si no la ip de la maquina servidor
    private String host = "localhost";
    
    //Variables del frame 
    private String mensaje;
    private Main frame;
    private JButton[][][] botones;
    private ActionListener ac;
    
    //Variables para cargar las imagenes
    private Image X;
    private Image O;
    
    private boolean turno;
    
    public Cliente(Main frame){
        try {
            this.frame = frame;
            X = ImageIO.read(getClass().getResource("X.png"));
            O = ImageIO.read(getClass().getResource("O.png"));
            cliente = new Socket(host,puerto);
            in = new DataInputStream(cliente.getInputStream());
            out = new DataOutputStream(cliente.getOutputStream());
            botones = this.frame.getBotones();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        try{
            //Cuando conectamos con el servidor, este nos devuelve el turno de juego
            mensaje =  in.readUTF();
            String split[] = mensaje.split(";");
            frame.cambioTexto(split[0]);
            String XO = split[0].split(" ")[1];
            turno = Boolean.valueOf(split[1]);
            
            //Ciclo infinito, para estar escuchando por los movimientos de los jugadores
            while(true){

                mensaje = in.readUTF();
                
                String[] mensajes = mensaje.split(";");
                int xo = Integer.parseInt(mensajes[0]);
                int f = Integer.parseInt(mensajes[1]);
                int c = Integer.parseInt(mensajes[2]);
                int t = Integer.parseInt(mensajes[3]);
                /*
                Modificamos el boton que se apretro poniendo la imagen de acuerdo al turno que estaba jugando
                */
                if(xo == 1)
                    botones[f][c][t].setIcon(new ImageIcon(X));
                else
                    botones[f][c][t].setIcon(new ImageIcon(O));

                botones[f][c][t].removeActionListener(botones[f][c][t].getActionListeners()[0]);
                turno = !turno;
                
                
                if(XO.equals(mensajes[4])){
                    JOptionPane.showMessageDialog(frame, "GANASTEEEEEE!");
                    new Main().setVisible(true);
                    frame.dispose();
                }else  if("EMPATE".equals(mensajes[4])){
                    JOptionPane.showMessageDialog(frame, "EMPATE!");
                    new Main().setVisible(true);
                    frame.dispose();
                }
                else  if(!"NADIE".equals(mensajes[4]) && !mensajes[4].equals(mensajes[0])){
                    JOptionPane.showMessageDialog(frame, "PERDISTE BUUUUU!");
                    new Main().setVisible(true);
                    frame.dispose();
                }
                
                
              
            }
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
   
    public void enviarTurno(int f,int c, int t){
      
        try {
            if(turno){
                String  datos = "";
                datos += f + ";";
                datos += c + ";";
                datos += t + ";";
                out.writeUTF(datos);
            }
            else{
                JOptionPane.showMessageDialog(frame, "Espera tu turno");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    } 

   
}
